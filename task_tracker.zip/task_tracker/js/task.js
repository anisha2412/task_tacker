$(document).on('click',"#add_task_btn",function()
{ 		
	var title = $('#title').val();
	var description = $('#description').val();
	var due_date=$("#due_date").val();
	
	if(title=="" )
	{
		alert("Please enter title");
	}
	else if(due_date=="" )
	{
		alert("Please select task due date")
	}	
	else
	{	
	let myform = document.getElementById("addtask");  
    let fd = new FormData(myform);
		$.ajax({
            url: 'addtask.php',
		   	type: 'POST',
		   	data:new FormData(document.getElementById("addtask")),
		   	contentType:false,
		   	cache:false,
		   	processData:false,
		  	headers: "Content-Type':'application/x-www-form-urlencoded'",
		   	async: false,
               dataType: 'json', 
            success: function(response) {             
                if (response.status === 'success') {
                    alert(response.message); 
                    document.getElementById('exampleModal').style.display = 'none';
                    location.reload(); 
                } else {
                    alert(response.message);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {   
                alert("Some error occurred.");
            }
        
    });
 		
	}
}); 



$(document).ready(function() {
    $('.edit-task').click(function(e) {
        e.preventDefault(); 
        var id = $(this).data('id');       
        $.ajax({
            url: 'edittask.php',
            type: 'GET',
            data: {id: id},
            success: function(response) {              
                var data = JSON.parse(response);
                if (data.status === 'success') {
                    var task = data.data;
                    $('#update_title').val(task.title);
                    $('#id').val(task.id);
                    $('#update_description').val(task.description);

                     var dueDate = new Date(task.due_date);
                     var formattedDueDate = dueDate.getFullYear() + '-' + ('0' + (dueDate.getMonth() + 1)).slice(-2) + '-' + ('0' + dueDate.getDate()).slice(-2);
 
                     $('#update_due_date').val(formattedDueDate);

                } else {
                    console.log("Error: " + data.message);
                }
            },
            error: function(xhr, status, error) {
                console.log("Error: " + error);
            }
        });
    });
});



$(document).on('click',"#edit_task_btn",function()
{ 		
	var title = $('#update_title').val();
	var description = $('#update_description').val();
	var due_date=$("#update_due_date").val();
	
	if(title=="" )
	{
		alert("Please enter title");
	}
	else if(due_date=="" )
	{
		alert("Please select task due date")
	}	
	else
	{	
	let myform = document.getElementById("edittask");  
    let fd = new FormData(myform);
		$.ajax({
            url: 'updatetask.php',
		   	type: 'POST',
		   	data:new FormData(document.getElementById("edittask")),
		   	contentType:false,
		   	cache:false,
		   	processData:false,
		  	headers: "Content-Type':'application/x-www-form-urlencoded'",
		   	async: false,
               dataType: 'json', 
            success: function(response) {             
                if (response.status === 'success') {
                    alert(response.message); 
                    document.getElementById('editexampleModal').style.display = 'none';
                    location.reload(); 
                } else {
                    alert(response.message);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {   
                alert("Some error occurred.");
            }
        
    });
 		
	}
}); 

$(document).ready(function() {
    $('.delete-task').click(function(e) {
        e.preventDefault();
        var id = $(this).data('id');

        if (confirm("Are you sure you want to delete this task?")) {

            $.ajax({
                url: 'deletetask.php',
                type: 'POST',
                data: {id: id},
                dataType: 'json', 
                success: function(response) {
                    alert(response.message); 
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error("Error:", error);
                    alert("Failed to delete task. Please try again later.");
                }
            });
        }
    });
});
